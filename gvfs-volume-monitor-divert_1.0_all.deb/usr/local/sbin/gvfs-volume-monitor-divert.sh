#!/bin/bash
flag="$1"
divert() {
  if [[ "$flag" != "--remove" ]]; then
    dpkg-divert --rename --add --divert "$1.bak" "$1"
    mkdir -p -m 0755 "$(dirname "$1")"
    ln -sf /dev/null "$1"
  else
    [[ -f "$1.bak" || "$1" -ef /dev/null ]] && rm -f "$1"
    dpkg-divert --rename --remove "$1"
  fi
}
divert /usr/share/dbus-1/services/org.gtk.vfs.AfcVolumeMonitor.service
divert /usr/share/dbus-1/services/org.gtk.vfs.GPhoto2VolumeMonitor.service
divert /usr/share/dbus-1/services/org.gtk.vfs.GoaVolumeMonitor.service
divert /usr/share/dbus-1/services/org.gtk.vfs.MTPVolumeMonitor.service
#divert /usr/share/dbus-1/services/org.gtk.vfs.UDisks2VolumeMonitor.service
