if [[ -f "$1.bak" || "$1" -ef /dev/null ]]; then
  rm -f "$1"
fi
dpkg-divert --rename --remove "$1"
