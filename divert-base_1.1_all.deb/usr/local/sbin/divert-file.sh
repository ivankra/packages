#!/bin/bash
dpkg-divert --rename --add --divert "$1.bak" "$1"
mkdir -p -m 0755 "$(dirname "$1")"
ln -sf /dev/null "$1"
