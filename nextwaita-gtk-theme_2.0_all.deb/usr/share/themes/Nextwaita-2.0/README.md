# Nextwaita
a GTK3 theme
